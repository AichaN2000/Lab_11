
import React from "react";
const HomePage = () => {
    return (
        <div>
            <h1>Welcome to my website!</h1>
            <p>This is the homepage.</p>
        </div>
    );
};
export default HomePage;